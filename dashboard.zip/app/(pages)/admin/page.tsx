const AdminPage = () => {
  return (
    <div className=''>AdminPage</div>
  )
}

export default AdminPage